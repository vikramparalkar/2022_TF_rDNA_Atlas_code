library(ggplot2)
library(cowplot)
library(gridExtra)
library(rstudioapi)
library(crayon)

programVersion <- "1.0"

programName <- "R1B0ZONE"
task1name <- "ThresholdFinder"
task2name <- "PeakAlgorithm"

#Supported Tasks (enter the number corresponding to the desired task):
#1. ThresholdFinder (Troubleshooting: Don't worry about this task, start with 2)
#2. PeakAlgorithm (Generate images and find threshold)
#3. AppendBinary (Generate raw/binary .txt file)

####User Input####
colnums <- 3:911
#colnums <- c(90,181,188,190,236,266)
#colnums <- c(772,686,657,603,429,409,771)
task <- c(3)

maxColNum <- NULL
maxColNumHuman <- 1251
maxColNumMouse <- 911
binw <- NULL
zero_thresh_factor <- NULL
zero_thresh <- NULL
zero_w <- NULL
merge_width <- NULL
real_peak_width <- NULL
minimum_real_peak_factor <- NULL
peak_max_factor <- NULL
w <- NULL
cutoff_factor_coefficient <- NULL

#### DEFINE FUNCTIONS ####

#Function 1. (Finding the current date and species of file)
find.date.time.path.name.and.species <- function() {
  #Correct for col numbers if task contains 3
  if (length(which(task == 3)) != 0) {
    #colnums <<- 3:maxColNum
  }
  #Find date and time
  date_and_time <- Sys.time()
  date_and_time <- toString(date_and_time)
  date_and_time <- strsplit(date_and_time," ")
  date_and_time <- date_and_time[[1]]
  date_and_time <- paste(date_and_time[1],"_",date_and_time[2],sep="")
  date_and_time <- strsplit(date_and_time,":")
  date_and_time <- date_and_time[[1]]
  date_and_time <- paste("(",date_and_time[1],"h",date_and_time[2],
                         "m",date_and_time[3],"s",")",sep="")
  
  #Find path
  input_filepath <- file.choose()
  #Find species through file name and assign parameters based on species
  input_filepath_split <- strsplit(input_filepath,"/")[[1]]
  input_filename <- input_filepath_split[length(input_filepath_split)]
  input_filename_split <- strsplit(input_filename,"_")[[1]]
  species <- NULL
  loop.input_filename_split <- 1:length(input_filename_split)
  for (i in loop.input_filename_split) {
    if (input_filename_split[i] == "hg19") {
      species <- "Human"
      binw <<- 0.02
      zero_thresh_factor <<- 0.15
      zero_w <<- 8
      merge_width <<- 300
      real_peak_width <<- 10
      minimum_real_peak_factor <<- 0.3
      peak_max_factor <<- 10
      w <<- 2.5
      cutoff_factor_coefficient <<- 6
      maxColNum <- maxColNumHuman
    }
    if (input_filename_split[i] == "mm9") {
      species <- "Mouse"
      binw <<- 0.02
      zero_thresh_factor <<- 0.15
      zero_w <<- 8
      merge_width <<- 300
      real_peak_width <<- 10
      minimum_real_peak_factor <<- 0.3
      peak_max_factor <<- 10
      w <<- 2.5
      cutoff_factor_coefficient <<- 8.5
      maxColNum <- maxColNumMouse
    }
  }
  
  #### INPUT CORRECTIONS ####
  num1 <- which(colnums == 1)
  if (length(num1) != 0) {
    colnums <- colnums[-c(num1)]
  }
  num2 <- which(colnums == 2)
  if (length(num2) != 0) {
    colnums <- colnums[-c(num2)]
  }
  numGreater <- which(colnums > maxColNum)
  if (length(numGreater) != 0) {
    colnums <- colnums[-c(numGreater)]
  }
  
  #Assemble return value
  date_path_and_species <- list("date" = date_and_time, "path" = input_filepath,
                                "name" = input_filename,"species" = species)
  return(date_path_and_species)
}

#Function 2. (Prompt user to select a save directory)
select.save.directory <- function() {
  cat(bold("\n( 2 ) ") %+% bgWhite("Please select a directory to export your saved files to.\n"))
  flush.console()
  Sys.sleep(1)
  save_dir <- selectDirectory()
  return(save_dir)
}


#Function 3. (Display progress in the console)
disp.progress <- function(curr_idx, total_idx, unique_ID) {
  curr_idx <- toString(i-1)
  num_idx <- toString(length(loop.col))
  progress1 <- paste("\nProcessing element ", curr_idx, " of ", num_idx, "...\n", sep="")
  progress2 <- paste("        ", unique_ID,"\n")
  cat(progress1)
  cat(progress2)
  flush.console()
  Sys.sleep(0.5)
}

#Function 4. (Helper function to use in Function 5 for type conversion)
convert.to.double <- function(col) {
  return(as.double(paste(col)))
}

#Function 5. (Import file and convert to numeric)
import.data.and.find.unique.IDs <- function(input_file_info) {
  #Import whole file
  whole_file <- read.table(input_file_info$path,sep="\t",header=T)
  TF_signal <- NULL
  unique_IDs <- NULL
  other_info <- NULL
  #Format TF_signal to include all data and save unique IDs
  if (input_file_info$species == "Human") {
    TF_signal <- whole_file[,colnums]
    unique_IDs <- whole_file[43005,colnums]
    unique_IDs <- unique_IDs[-c(1)]
    unique_IDs <- unique_IDs[,1:length(unique_IDs)]
    unique_IDs <- c("Position",unique_IDs)
    other_info <- c(TF_signal[c(43001:43013),])
    TF_signal <- TF_signal[-c(43001:43013),]
  } else if (input_file_info$species == "Mouse") {
    TF_signal <- whole_file[,colnums]
    unique_IDs <- whole_file[45311,colnums]
    unique_IDs <- unique_IDs[-c(1)]
    unique_IDs <- unique_IDs[,1:length(unique_IDs)]
    unique_IDs <- c("Position",unique_IDs)
    other_info <- TF_signal[c(45307:45319),]
    TF_signal <- TF_signal[-c(45307:45319),]
  }
  #Convert TF_signal to correct types
  TF_signal <- sapply(TF_signal,convert.to.double) #(2.)
  TF_signal <- as.data.frame(TF_signal)
  #Assemble return data
  data.and.unique.IDs <- list("TF_signal" = TF_signal, 
                              "unique_IDs" = unique_IDs,
                              "other_info" = other_info)
  cat(green$bold("\nFile Imported Successfully.\n"))
  flush.console()
  Sys.sleep(0.5)
  return(data.and.unique.IDs)
}

#Function 6. (Log transform data calculations)
log.transform.col <- function(position,col) {
  #Calculate the log of the column vector input
  TF_log <- data.frame(Position=position, Log_Signal=log10(col))
  TF_log[order(TF_log$Log_Signal),]
  TF_log <- TF_log[(which(TF_log$Log_Signal >= -1)[1]):length(TF_log$Log_Signal),]
  #Create ggplot object for position vs. log transformation of data
  log_plot <- ggplot() + 
    geom_density(data=TF_log,aes(x=Log_Signal),alpha=0.2, fill="#FF6666")
  #Find log plot limits
  log_plot_data <- layer_data(log_plot,1)
  x <- unlist(log_plot_data$x)
  density <- unlist(log_plot_data$density)
  log_plot_data <- data.frame("x" = x,"density" = density)
  xlim <- c(-1,log_plot_data[length(log_plot_data$x),1])
  log_plot_data <- log_plot_data[order(log_plot_data$density),]
  ylim <- c(0,1.05*log_plot_data[(length(log_plot_data$density)),2])
  log_plot_data <- log_plot_data[order(log_plot_data$x),]
  #Assemble return data
  log_transform_data <- list("log_plot_data" = log_plot_data, 
                             "log_plot" = log_plot, "xlim" = xlim, 
                             "ylim" = ylim)
  return(log_transform_data)
}

#Function 7. (Dydx data calculations)
dydx.col <- function(position,col) {
  #Create dydx dataframe
  TF_dydx <- data.frame(x = position[1:(length(position)-1)],
                        y = (diff(col)*(1/binw)))
  #Create ggplot object for position vs. dydx of log transformation of data
  dydx_plot <- ggplot() + geom_line(data=TF_dydx, aes(x=x,y=y))
  #Find dydx plot limits (xlim is the same as for log transform plot)
  ylim <- c(1.05*min(TF_dydx$y),1.05*max(TF_dydx$y))
  #Assemble return data
  dydx_data <- list("dydx_plot_data" = TF_dydx, "dydx_plot" = dydx_plot, 
                    "ylim" = ylim)
  return(dydx_data)
}

#Function 8. (Calculate threshold from dydx data)
calculate.threshold <- function(dydx_plot_data) {
  #Only consider data at x > 0.25 
  thresh_dydx_data <- data.frame(dydx_plot_data[which(dydx_plot_data[,1] >= 0.25),1],
                                 dydx_plot_data[which(dydx_plot_data[,1] >= 0.25),2])
  #Define zero band for dydx plot
  dydx_min <- abs(min(thresh_dydx_data[,2]))
  dydx_max <- max(thresh_dydx_data[,2])
  if (dydx_max > dydx_min) {
    zero_thresh <<- dydx_max * zero_thresh_factor
  } else {
    zero_thresh <<- dydx_min * zero_thresh_factor
  }
  
  zero_band <- c(-1*zero_thresh,zero_thresh)
  beginning <- NULL
  end <- NULL
  thresh_x_region <- which(thresh_dydx_data[,1] <= 1)
  dydx_neg <- NULL
  if (input_file_info$species == 'Human') {
    dydx_neg <- which(thresh_dydx_data[thresh_x_region,2] <= -1*zero_thresh)[1]
  } else {
    dydx_neg <- which(thresh_dydx_data[thresh_x_region,2] <= 0)[1]
  }
  
  if (!is.na(dydx_neg)) {
    #Set up loops
    loop.pos <- dydx_neg:(length(thresh_dydx_data[,1]))
    #loop.pos <- dydx_min:(length(thresh_dydx_data[,1]))
    loop.zero_w <- 1:zero_w
    #Find the beginning of the first region where zero_w number of dydx values
    #fall within the values of zero_band
    for (i in loop.pos) {
      curr_data <- thresh_dydx_data[i,2]
      if (isTRUE(curr_data > zero_band[2] || curr_data < zero_band[1])) {
      } else {
        satisfy_length <- TRUE
        for (j in loop.zero_w) {
          test_ele <- thresh_dydx_data[i+j,2]
          if (isTRUE(test_ele > zero_band[2] || test_ele < zero_band[1])) {
            satisfy_length <- FALSE
          }
        }
        if (isTRUE(satisfy_length) && ((i+j) <= length(thresh_dydx_data[,1]))) {
          beginning <- thresh_dydx_data[i,1]
          end <- thresh_dydx_data[i+j,1]
          break()
        }
      }
    }
  }
  #Assemble return data
  thresh_zone_in_x <- list("beginning" = beginning, "end" = end)
  raw_thresh <- toString(round(10^beginning,3))
  cat("         Threshold: " %+% toString(raw_thresh))
  return(thresh_zone_in_x)
}

#Function 9. (Create supplementary plot objects)
create.plot.objects <- function(limits,thresh_zone_in_x,input_file,colnum) {
  #Define zero band
  zero_band <- c(-1*zero_thresh,zero_thresh)
  binary_threshold <- thresh_zone_in_x$beginning
  #Correct for beginning if a threshold wasn't found
  if (is.null(thresh_zone_in_x$beginning)) {
    thresh_zone_in_x$beginning <- limits$log_x[2]
    binary_threshold <- 0
  }
  #Correct for end if out of bounds
  if (is.null(thresh_zone_in_x$end)) {
    thresh_zone_in_x$end <- limits$log_x[2]
    binary_threshold <- 0
  }
  #Create dataframes for threshold lines and rectangles for log and dydx
  t_x_log <- c(thresh_zone_in_x$beginning,thresh_zone_in_x$beginning)
  t_y_log <- c(limits$log_y[1],limits$log_y[1])
  line_and_rect_log <- data.frame(line_x = t_x_log, line_y = t_y_log,
                                  rect_x1 = c(thresh_zone_in_x$beginning),
                                  rect_x2 = c(thresh_zone_in_x$end),
                                  rect_y1 = c(limits$log_y[1]),
                                  rect_y2 = c(limits$log_y[2]),
                                  l=c(thresh_zone_in_x$beginning))
  t_x_dydx <- c(thresh_zone_in_x$beginning,thresh_zone_in_x$beginning)
  t_y_dydx <- c(limits$dydx_y[1],limits$dydx_y[1])
  line_and_rect_dydx <- data.frame(line_x=t_x_dydx,line_y=t_y_dydx,
                                   rect_x1=c(thresh_zone_in_x$beginning),
                                   rect_x2=c(thresh_zone_in_x$end),
                                   rect_y1=c(limits$dydx_y[1]),
                                   rect_y2=c(limits$dydx_y[2]),
                                   l=c(thresh_zone_in_x$beginning))
  #Create zero band for dydx plot
  z_x_dydx <- c(limits$dydx_x[1],limits$dydx_x[2])
  z_neg_y_dydx <- c(zero_band[1],zero_band[1])
  z_pos_y_dydx <- c(zero_band[2],zero_band[2])
  zero_band_dydx <- data.frame(x = z_x_dydx, y1 = z_pos_y_dydx, y2 = z_neg_y_dydx,
                               y0 = c(0,0))
  ####Create dataframe for plot stats
  xvals <- c(0,0,0,0,0,0,0)
  yvals <- c(7,6,5,4,3,2,1)
  logt <- NULL
  t <- NULL
  if (thresh_zone_in_x$beginning == limits$log_x[2]) {
    logt <- "Log(Threshold): None Found..."
    t <- "Threshold: None Found..."
    #Save log10 threshold for task 2
    if (binary_threshold == 0) {
      threshold_log10_main <<- "-INF"
    } else {
      threshold_log10_main <<- toString(round(binary_threshold,3))
    }
    #Save threshold for task 2
    if (binary_threshold == 0) {
      threshold_main <<- '0'
    } else {
      threshold_main <<- toString(round(10^binary_threshold,3))
    }
  } else {
    logt <- paste("Log(Threshold): ", 
                  toString(round(thresh_zone_in_x$beginning,3)),sep="")
    t <- paste("Threshold: ",
               toString(round(10^thresh_zone_in_x$beginning,3)),sep="")
    #Save log10 threshold for task 2
    threshold_log10_main <<- toString(round(thresh_zone_in_x$beginning,3))
    #Save threshold for task 2
    threshold_main <<- toString(round(10^thresh_zone_in_x$beginning,3))
  }
  lab <- c(logt, t,
           paste("Zero Band Radius: ",toString(zero_band[2]),sep=""),
           paste("Length of Zero Zone: ",toString(zero_w),sep=""),
           paste("Bin Width: ",toString(binw),sep=""),
           paste("Column Number: ",toString(colnums[colnum]),sep=""),
           paste("Input File Name: ",input_file,sep=""))
  image_stats <- data.frame(x=xvals,y=yvals,l=lab)
  
  no_thresh <- F
  if (binary_threshold == 0) {
    no_thresh <- T
  }
  #Assemble return data
  plot_objects_and_thresh <- list("line_and_rect_log" = line_and_rect_log,
                                  "line_and_rect_dydx" = line_and_rect_dydx,
                                  "zero_band_dydx" = zero_band_dydx,
                                  "image_stats" = image_stats,
                                  "threshold" = round(10^thresh_zone_in_x$beginning,3),
                                  "no_thresh" = no_thresh)
  return(plot_objects_and_thresh)
}

#Function 10. (Update plots with new objects)
update.plots <- function(log_transform_col, dydx_col, plot_objects_and_thresh, 
                         unique_IDs, input_file_info, colnum) {
  #Update log plot
  log_transform_col$log_plot <- log_transform_col$log_plot + 
    geom_rect(data = plot_objects_and_thresh$line_and_rect_log,
              mapping = aes(xmin = rect_x1, xmax = rect_x2, ymin = rect_y1,
                            ymax = rect_y2),
              color = "darkred", fill = "darkred", alpha = 0.25) +
    geom_line(data = plot_objects_and_thresh$line_and_rect_log, aes(x = line_x, y = line_y),
              col = "#FF6666", size = 2) +
    guides(col = FALSE) + guides(alpha = FALSE) +
    labs(x = "Log10 Signal", y = "Density") +
    labs(title=paste("Log10 Signal Density Distribution ",
                     unique_IDs[colnum],"_",input_file_info$date, sep="")) + 
    theme_bw() + theme(plot.background = element_rect(fill="white")) +
    theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
    coord_cartesian(xlim = log_transform_col$xlim, ylim = log_transform_col$ylim,
                    expand = F)
  #Update dydx plot
  dydx_col$dydx_plot <- dydx_col$dydx_plot + 
    geom_rect(data = plot_objects_and_thresh$line_and_rect_dydx,
              mapping=aes(xmin = rect_x1, xmax = rect_x2, ymin = rect_y1,
                          ymax = rect_y2), color = "darkred", fill = "darkred",
              alpha = 0.25) +
    geom_line(data = plot_objects_and_thresh$line_and_rect_dydx, aes(x = line_x, y = line_y),
              col = "#FF6666", size = 2) +
    geom_line(data=plot_objects_and_thresh$zero_band_dydx, aes(x = x, y = y1), 
              linetype="dotted") + 
    geom_line(data=plot_objects_and_thresh$zero_band_dydx, aes(x = x, y = y2),
              linetype="dotted") + 
    geom_line(data=plot_objects_and_thresh$zero_band_dydx, aes(x = x, y = y0), 
              col="#FF6666") +
    labs(x="Log10 Signal", y="Dydx Density") +
    labs(title=paste("Dydx of Log10 Signal Density Distribution ", 
                     unique_IDs[colnum],sep="")) + 
    theme_bw() + theme(plot.background = element_rect(fill = "white")) +
    theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
    coord_cartesian(xlim = log_transform_col$xlim, ylim = dydx_col$ylim, expand = F)
  #Create stat plot
  stats_plot <- ggplot(data = plot_objects_and_thresh$image_stats, aes(x = x, y = y, label = l)) + 
    geom_text() + theme_bw() + theme(plot.background = element_rect(fill = "white")) +
    labs(title="Image Properties") +
    theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
    theme(axis.title.x = element_blank(), axis.text.x = element_blank(),
          axis.ticks.x = element_blank()) +
    theme(axis.title.y = element_blank(), axis.text.y = element_blank(),
          axis.ticks.y = element_blank()) +
    coord_cartesian(ylim = c(0,8), expand = F)
  #Assemble return data
  updated_plots <- list("log" = log_transform_col$log_plot,
                        "dydx" = dydx_col$dydx_plot,
                        "stats" = stats_plot)
  return(updated_plots)
}

#Function 11. (Create raw histogram)
create.raw.histogram <- function(unique_IDs, position, col, colnum) {
  #Determine ylimits for raw histogram
  ylim_raw <- c(0,1.05*(max(col)))
  #Save ymax globally for task 2 .txt file
  ymax_main <<- toString(ylim_raw[2])
  #Create a data frame to use in plotting
  TF_signal <- data.frame(x = position, y = col)
  #Create a data frame to display how wide the merging window is
  merge_frame <- data.frame(x1=0,x2=merge_width,y1=0,y2=ylim_raw[2])
  #Plot raw histogram and merging frame
  raw_plot <- ggplot() + geom_bar(data = TF_signal, aes(x = x, y = y), stat ="identity", 
                                  width = 1.0, fill = "gray", alpha = 0.5) +
    geom_rect(data = merge_frame, mapping = aes(xmin = x1, xmax = x2,
                                                ymin = y1, ymax = y2), 
              color = "darkred", fill = "darkred", alpha = 0.25) +
    labs(x = "position", y = "normalized signal") +
    labs(title = unique_IDs[colnum]) + theme_bw() +
    theme(plot.background = element_rect(fill = "white")) +
    theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
    coord_cartesian(ylim = ylim_raw, expand = F)
  #Assemble return data
  return(raw_plot)
}

#Function 12. (Create preliminary binary data)
create.preliminary.binary.data <- function(plot_objects_and_thresh,col) {
  #Make data binary without corrections
  raw_thresh <- plot_objects_and_thresh$threshold
  greater_than <- which(col >= raw_thresh)
  less_than <- which(col < raw_thresh)
  b_data <- rep(0,length(col))
  if (isFALSE(plot_objects_and_thresh$no_thresh)) {
    b_data[greater_than] <- raw_thresh
  }
  #Assemble return data
  return(b_data)
}

#Function 13. (Merging Correction)
merging.correction <- function(b_data,plot_objects_and_thresh,col) {
  #(1) ISOLATE PEAK REGIONS AND PUT INTO A LIST
  #Find where ones are in b_data
  indices_of_ones <- which(b_data != 0)
  #Find where zeros are in b_data
  indices_of_zeros <- which(b_data == 0)
  #Length of these 1 zones
  one_zone_lengths <- diff(indices_of_ones)-1
  #Length of these 0 zones
  zero_zone_lengths <- diff(indices_of_zeros) - 1
  #Find the ends of these merge zones and corresponding indices
  end_merge_zones <- which(one_zone_lengths != 0)
  # Create list to hold merge zones
  zones_list <- vector("list",length(end_merge_zones)+1)
  if (length(end_merge_zones != 0)) {
    #Create loop for end merge zones
    emz.loop <- 1:length(end_merge_zones)
    #Create start index
    start_idx <- 1
    for (i in emz.loop) {
      raw_idx_indices <- start_idx:end_merge_zones[i]
      zones_list[[i]] <- indices_of_ones[raw_idx_indices]
      start_idx <- end_merge_zones[i] + 1
    }
    last_one_region <- indices_of_ones[end_merge_zones[length(end_merge_zones)]+1]:
      indices_of_ones[length(indices_of_ones)]
    zones_list[[length(zones_list)]] <- last_one_region
  } else {
    zones_list[[1]] <- list(indices_of_ones[1]:indices_of_ones[length(indices_of_ones)])
  }
  #(2) COLLECT RAW DATA IN THESE ZONES
  #Import raw data to function
  raw_data <- col
  #Set up a list for raw data in peak regions
  raw_data_zones_list <- vector("list",length(zones_list))
  #Create loop to get the raw data at these indices
  rd.loop <- 1:length(raw_data_zones_list)
  for (i in rd.loop) {
    curr_region <- unlist(zones_list[[i]])
    raw_data_zones_list[[i]] <- raw_data[curr_region]
  }
  #(3) MERGING ALGORITHM
  raw_thresh <- plot_objects_and_thresh$threshold
  if (length(raw_data_zones_list) == 1) {
    
  } else {
    rdzl.loop <- 2:length(raw_data_zones_list)
    for (i in rdzl.loop) {
      prev_zone <- raw_data_zones_list[[i-1]]
      curr_zone <- raw_data_zones_list[[i]]
      prev_max <- max(prev_zone)
      curr_max <- max(curr_zone)
      if ((prev_max/curr_max) <= 3 && (prev_max/curr_max) >= 0.33) {
        last_of_prev_idx <- zones_list[[i-1]][length(zones_list[[i-1]])]
        first_of_curr_idx <- zones_list[[i]][1]
        if (first_of_curr_idx - last_of_prev_idx <= merge_width) {
          b_data[last_of_prev_idx:first_of_curr_idx] <- raw_thresh
        }
      }
    }
  }
  return(b_data)
}

#Function 14. (False Peak Correction)
false.peak.correction <- function(b_data) {
  #Find where zeros are in b_data
  indices_of_zeros <- which(b_data == 0)
  #Length of these zero zones
  zero_zone_lengths <- diff(indices_of_zeros)-1
  #Which lengths are lower than real peak thresh
  fake_zones <- which(zero_zone_lengths < real_peak_width)
  if (length(fake_zones) > 0) {
    start_of_fake_peaks <- indices_of_zeros[fake_zones]+1
    loop.fz <- 1:length(fake_zones)
    for (i in loop.fz) {
      curr_fake <- start_of_fake_peaks[i]
      b_data[curr_fake:(curr_fake+zero_zone_lengths[fake_zones[i]])] <- 0
    }
  }
  #Assemble return data
  return(b_data)
}

#Function 15. (Gets rid of peaks that don't reach a minimum value)
minimum.signal.correction <- function(b_data,plot_objects_and_thresh,col) {
  #Set up data frame for binary txt data
  txt_data <- b_data
  #Define raw_thresh
  raw_thresh <- plot_objects_and_thresh$threshold
  #Find all zeros
  peak_regions <- which(b_data == 0)
  #Length of these regions
  peak_lengths <- diff(peak_regions)-1
  #Isolate beginnings of these regions
  peak_start_indices <- which(peak_lengths > 1)
  if (raw_thresh < cutoff_factor_coefficient) {
    cutoff_factor <<- (cutoff_factor_coefficient/raw_thresh) + 0.5
  } else {
    cutoff_factor <<- 1 + 0.5
  }
  #Catch peak regions at very beginning
  if(b_data[1] != 0) {
    curr_data <- col[1:which(b_data == 0)[1]-1]
    txt_data[1:(which(b_data == 0)[1]-1)] <- max(curr_data)
    b_data[1:(which(b_data == 0)[1]-1)] <- cutoff_factor*raw_thresh
  }
  #Catch peak regions at very end
  if(b_data[length(b_data)] != 0) {
    curr_data <- col[which(b_data == 0)[length(which(b_data == 0))]:length(col)]
    txt_data[which(b_data == 0)[length(which(b_data == 0))]:length(col)] <- max(curr_data)
    b_data[which(b_data == 0)[length(which(b_data == 0))]:length(col)] <- cutoff_factor*raw_thresh
  }
  if (length(peak_start_indices) > 0) {
    peak_starts <- peak_regions[peak_start_indices]+1
    loop.pr <- 1:length(peak_starts)
    #Cycle through peaks and take out the ones that dont fit the magnitude criteria
    for (i in loop.pr) {
      curr_region <- peak_starts[i]
      curr_data <- col[(curr_region:(curr_region+
                                       peak_lengths[peak_start_indices[i]]))]
      num_max_thresh <- which(curr_data >= cutoff_factor*raw_thresh)
      if (length(num_max_thresh) == 0) {
        b_data[curr_region:(curr_region+peak_lengths[peak_start_indices[i]])] <- 0
        txt_data[curr_region:(curr_region+peak_lengths[peak_start_indices[i]])] <- 0
      } else {
        b_data[curr_region:(curr_region+peak_lengths[peak_start_indices[i]])] <- cutoff_factor*raw_thresh
        txt_data[curr_region:(curr_region+peak_lengths[peak_start_indices[i]])] <- max(curr_data)
      }
    }
  }
  #Assemble return data
  txt_b_data <<- txt_data
  return(b_data)
}

#Function 16. (Applies all of the peak calling correction measures)
peak.calling.corrections <- function(b_data,plot_objects_and_thresh,col) {
  if (isFALSE(plot_objects_and_thresh$no_thresh)) {
    b_data <- merging.correction(b_data,plot_objects_and_thresh,col)
    b_data <- false.peak.correction(b_data)
    b_data <- minimum.signal.correction(b_data,plot_objects_and_thresh,col)
  } else {
    b_data[1:length(b_data)] <- 0
    txt_b_data <<- b_data
  }
  
  #Assemble return data
  return(b_data)
}

#Function 17. (Organizes binary data into relevant data frames) 
create.binary.data.frames <- function(position,b_Data,plot_objects_and_thresh) {
  #Define raw_thresh
  raw_thresh <- plot_objects_and_thresh$threshold
  #Create a vector to store binary data in 0s and 1s
  ones_data <- rep(0,length(b_Data))
  loop.b <- 1:length(b_Data)
  for (i in loop.b) {
    if (b_Data[i] != 0) {
      ones_data[i] <- 1
    }
  }
  #Create a binary data frame using 0s and the raw_thresh for plotting
  b_Data_thresh <- data.frame(x=position,y=b_Data)
  #Create a binary data frame using 0s and 1s for file export
  b_Data_ones <- data.frame(x=position,y=ones_data)
  #Create a data frame for plotting the threshold line on the histogram
  t_Data <- data.frame(x=c(min(position),max(position)),
                       y=c(raw_thresh,raw_thresh))
  #Assemble return data
  binary_and_threshold_data <- list("binary_thresh" = b_Data_thresh,
                                    "binary_ones" = b_Data_ones,
                                    "thresh_line" = t_Data)
  return(binary_and_threshold_data)
}

#Function 18. Create binary plot with thresh
binary.with.thresh.plot <- function(unique_IDs, position, col, 
                                    binary_and_thresh_frames, colnum, 
                                    plot_objects_and_thresh) {
  #Define raw_thresh
  raw_thresh <- plot_objects_and_thresh$threshold
  #Create data frame of raw data
  TF_signal <- data.frame(x=position,y=col)
  #Thresh Plot
  ht <- NULL
  if (isTRUE(plot_objects_and_thresh$no_thresh)) {
    ht <- ggplot() + geom_bar(data=TF_signal,aes(x=x,y=y),stat="identity",
                              width=1.0, fill="blue", alpha=0.5) +
      geom_bar(data=binary_and_thresh_frames$binary_thresh,aes(x=x,y=y),
               stat="identity",width=1.0,fill="red",alpha=0.5) +
      labs(x="position", y="binary normalized signal") +
      labs(title=unique_IDs[colnum]) + theme_bw() +
      theme(plot.background=element_rect(fill="white")) +
      theme(panel.grid.major=element_blank(),panel.grid.minor=element_blank()) +
      coord_cartesian(ylim=c(0,2*raw_thresh),expand=F)
  } else {
    cutoff_frame <- data.frame(x=c(0,length(position)), 
                               y=c(cutoff_factor*raw_thresh,cutoff_factor*raw_thresh))
    ht <- ggplot() + geom_bar(data=TF_signal,aes(x=x,y=y),stat="identity",
                              width=1.0, fill="blue", alpha=0.5) +
      geom_line(data=binary_and_thresh_frames$thresh_line,aes(x=x,y=y)) +
      geom_line(data=cutoff_frame, aes(x=x,y=y),linetype="dashed",color="red",alpha=0.5) +
      geom_bar(data=binary_and_thresh_frames$binary_thresh,aes(x=x,y=y),
               stat="identity",width=1.0,fill="red",alpha=0.5) +
      labs(x="position", y="binary normalized signal") +
      labs(title=unique_IDs[colnum]) + theme_bw() +
      theme(plot.background=element_rect(fill="white")) +
      theme(panel.grid.major=element_blank(),panel.grid.minor=element_blank()) +
      coord_cartesian(ylim=c(0,1.5*raw_thresh*cutoff_factor),expand=F)
  }
  #Assemble return data
  return(ht)
}

#Function 19. (Analysis of an individual column)
apply.analysis.to.col <- function(unique_IDs, input_file_info, 
                                  position, col, colnum) {
  #Log transform the data and get limits for plot
  log_transform_col <- log.transform.col(position,col)
  #Find the derivatives of data in the column and get ylimit for plot
  dydx_col <- dydx.col(log_transform_col[[1]][,1], log_transform_col[[1]][,2])
  #Calculate threshold from dydx data
  thresh_zone_in_x <- calculate.threshold(dydx_col[[1]])
  #Define plot objects
  limits <- list("log_x" = log_transform_col[[3]], "log_y" = log_transform_col[[4]],
                 "dydx_x" = log_transform_col[[3]], "dydx_y" = dydx_col[[3]])
  plot_objects_and_thresh <- create.plot.objects(limits,thresh_zone_in_x, input_file_info[[3]],
                                                 colnum)
  #Create raw histogram
  raw_plot <- create.raw.histogram(unique_IDs, position, col, colnum)
  #Create variables for preliminary binary data and corrected binary data
  preliminary_binary_data <- create.preliminary.binary.data(plot_objects_and_thresh,
                                                            col)
  #Run peak calling corrections
  b_Data <- peak.calling.corrections(preliminary_binary_data,
                                     plot_objects_and_thresh, col)
  
  #Make binary data frames
  binary_and_thresh_frames <- create.binary.data.frames(position, b_Data,
                                                        plot_objects_and_thresh)
  #Create peak calling plot
  peak_calling_plot <- binary.with.thresh.plot(unique_IDs, position, col, 
                                               binary_and_thresh_frames, colnum, 
                                               plot_objects_and_thresh)
  #Update plot information
  updated_plots <- update.plots(log_transform_col, dydx_col, plot_objects_and_thresh, 
                                unique_IDs, input_file_info, colnum)
  #Add raw histogram to plot list
  updated_plots <- append(updated_plots,list("raw" = raw_plot))
  updated_plots <- append(updated_plots,list("peak_calling" = peak_calling_plot))
  #Assemble return data
  analyzed_col <- list("plots" = updated_plots, "log_transform_data" = log_transform_col,
                       "dydx_data" = dydx_col, 
                       "binary_data" = binary_and_thresh_frames[1:2],
                       "threshold" = plot_objects_and_thresh$threshold)
  return(analyzed_col)
} 

#Function 20. (Extract all relevant data from column)
generate.deliverables <- function(task, unique_IDs, input_file_info,
                                  position, col, colnum) {
  full_analysis <- apply.analysis.to.col(unique_IDs, input_file_info,
                                         position, col, colnum)
  #Log
  log_plot_data <- full_analysis$log_transform_data
  log_plot <- full_analysis$plots$log
  #Dydx
  dydx_plot_data <- full_analysis$dydx_data
  dydx_plot <- full_analysis$plots$dydx
  #Stats
  stats_plot <- full_analysis$plots$stat
  #Raw
  raw_plot <- full_analysis$plots$raw
  #Binary
  binary_data_raw_thresh <- full_analysis$binary_data$binary_thresh
  binary_data_ones <- full_analysis$binary_data$binary_ones
  peak_calling_plot <- full_analysis$plots$peak_calling
  #Assemble return data
  deliverables <- list("log_plot" = log_plot, "dydx_plot" = dydx_plot, 
                       "stats_plot" = stats_plot, "raw_plot" = raw_plot,
                       "peak_calling_plot" = peak_calling_plot,
                       "binary_data_ones" = binary_data_ones)
  
  binary_data_ones <- binary_data_ones$y
  col <- c(col,txt_b_data)
  combined <- list(col)
  
  deliverables <- append(deliverables,list("combined_col" = combined))
  return(deliverables)
}

#Function 21. (Export relevant files according to contents of task)
save.deliverables <- function(input_file_info,deliverables,unique_ID,save_dir) {
  loop.task <- 1:length(task)
  for (i in loop.task) {
    if (task[i] == 1) {
      #Grid the plots
      g <- plot_grid(deliverables$log_plot,deliverables$dydx_plot,
                     deliverables$stats_plot,ncol=1,align="v",axis="b")
      #Create a save name with file path
      save_name <- paste(unique_ID,"_",programName,"_",task1name,"_",
                         input_file_info$date,".png",sep="")
      save_path <- paste(save_dir,"/",save_name,sep="")
      #Save the image
      save_plot(save_path,g,ncol=1,nrow=3,base_height=2.5,base_asp=6)
    } else if (task[i] == 2) {
      #Grid the plots
      g <- plot_grid(deliverables$log_plot,deliverables$dydx_plot,
                     deliverables$raw_plot,deliverables$peak_calling_plot,
                     ncol=1,align="v",axis="b")
      #Save File Paths
      save_name <- save_name <- paste(unique_ID,"_",programName,"_",task2name,"_",
                                      input_file_info$date,".png",sep="")
      save_path <- paste(save_dir,"/",save_name,sep="")
      #Save the plot
      save_plot(save_path,g,ncol=1,nrow=4,base_height=2.5,base_asp=6)
    } else if (task[i] == 3) {
      #.txt file will be made in the main body of script
    } 
  }
}

#### MAIN BODY OF SCRIPT ####
#Display tasks to be run
if (length(which(task == 1)) != 0) {
  cat(green$bold("\nTASK 1:\n"))
  cat(green$bold("ThresholdFinder\n"))
} else if (length(which(task == 2)) != 0) {
  cat(green$bold("\nTASK 2:\n"))
  cat(green$bold("PeakAlgorithm\n"))
} else if (length(which(task == 3)) != 0) {
  cat(green$bold("\nTASK 3:\n"))
  cat(green$bold("Create Raw and Binary .txt File"))
}
#Prompt user to select input file and add position column to colnum
cat(bold("\n( 1 ) ") %+% bgWhite("Please select the .txt file to be imported.\n"))
flush.console()
Sys.sleep(0.5)
colnums <- c(1,colnums)
#Determine relevant file info from input file
input_file_info <- find.date.time.path.name.and.species() 
#Display input file in console
cat("> " %+% input_file_info$path %+% "\n")
flush.console()
Sys.sleep(0.5)
#Error handling for invalid input files in console
if (is.null(input_file_info$species)) {
  cat(red$bold("\nERROR:\n"))
  cat(red("Species was not found in file name.\n"))
  cat(red("Please make sure that '_hg19_' (Human) or '_mm9_' (Mouse) is contained within the file name.\n"))
  cat(red("Please make sure that the file name ends with '.txt'.\n"))
  cat(red$bold("Please press the red stop sign at top right of console and run again"))
  flush.console()
  Sys.sleep(20)
}
#Prompt user to select save directory
save_dir <- select.save.directory()
#Display save directory in console
cat("> " %+% save_dir %+% "\n")
flush.console()
Sys.sleep(0.5)
#Create new save directory for files 
if (length(which(task == 2)) != 0) {
  save_dir <- paste(save_dir,"/",input_file_info$date,sep="")
  dir.create(save_dir)
}

#Display all relevant information in the console window
cat("_______________________________________________________________________\n")
cat(cyan$bold("Program Input Information:\n"))
cat(red$bold("(*) ") %+% bold("Species: ") %+% input_file_info$species %+% "\n")
cat(red$bold("(*) ") %+% bold("Input .txt file path: ") %+% input_file_info$path %+% "\n")
cat(red$bold("(*) ") %+% bold("Export file path: ") %+% save_dir %+% "\n")
cat(red$bold("(*) ") %+% bold("Number of Columns: ") %+% toString(length(colnums)-1) %+% "\n")
cat(red$bold("(*) ") %+% bold("Column Numbers: ") %+% toString(colnums[2:length(colnums)]) %+% "\n")
cat(red$bold("(*) ") %+% bold("Task: ") %+% toString(task) %+% "\n")
cat("_______________________________________________________________________\n")
cat(cyan$bold("Hard-Coded Parameters:\n"))
cat(red$bold("(*) ") %+% bold("Peak Merge Width: ") %+% toString(merge_width) %+% "\n")
cat(red$bold("(*) ") %+% bold("Minimum Real Peak Factor: ") %+% toString(minimum_real_peak_factor) %+% "\n")
cat(red$bold("(*) ") %+% bold("Peak Max Factor: ") %+% toString(peak_max_factor) %+% "\n")
cat(red$bold("(*) ") %+% bold("Real Peak Width: ") %+% toString(real_peak_width) %+% "\n")
cat(red$bold("(*) ") %+% bold("Zero Band Factor: ") %+% toString(zero_thresh_factor) %+% "\n")
cat(red$bold("(*) ") %+% bold("Length of Zero Zone: ") %+% toString(zero_w) %+% "\n")
cat("_______________________________________________________________________\n")
#Update user that file is being imported
cat(bold$cyan("\nImporting File...\n"))

#Import data and convert to proper data types. Extract unique IDs.
imported_data <- import.data.and.find.unique.IDs(input_file_info)
TF_signal <- imported_data$TF_signal
unique_IDs <- imported_data$unique_IDs
colnames(TF_signal) <- imported_data$unique_IDs
#Set up a loop to loop through all columns
loop.col <- 2:length(colnums)
#Set up a variable to hold .png info
peak_calling_info <- matrix(,nrow=(length(colnums)-1),ncol=13)
peak_calling_info_names <- c("Unique_ID","Col_Num","Log10_Threshold",
                             "Threshold","yMax","Zero_Band_Radius",
                             "Length_of_Zero_Zone","Bin_Width","Merge_Width",
                             "Min_Real_Peak_Factor","Peak_Max_Factor",
                             "Real_Peak_Width","Date_and_Time")
#Set up a variable to hold the combined data frame in case task contains 3
TF_signal_raw_and_binary <- NULL
thresh_cutoff_txt <- NULL
if (length(which(task == 3)) != 0) {
  TF_signal_raw_and_binary <- c(TF_signal[,1],TF_signal[,1])
  thresh_cutoff_txt <- c("Threshold","Cutoff")
}
#Run analysis on each column and save appropriate deliverables
for (i in loop.col) {
  #Set up variables to store relevant info for .txt file in task 2
  column_number <- toString(colnums[i])
  unique_ID <- unique_IDs[[i]][1]
  threshold_log10_main <- NULL
  threshold_main <- NULL
  ymax_main <- NULL
  date_and_time_of_saving <- NULL
  length_of_zero_zone <- toString(zero_w)
  bin_width <- toString(binw)
  cutoff_factor <- NULL
  txt_b_data <- NULL
  #Collect deliverables
  disp.progress((i-1), length(loop.col), unique_IDs[i])
  deliverables <- generate.deliverables(task, unique_IDs, input_file_info, 
                                        TF_signal$Position, TF_signal[,i], 
                                        i)
  zero_band_radius <- zero_thresh
  #Save deliverables
  save.deliverables(input_file_info,deliverables,unique_IDs[i],save_dir)
  #Populate file info dataframe if task contains 2
  if (length(which(task == 2)) != 0) {
    info_vector <- c(unique_ID,column_number,threshold_log10_main,
                     threshold_main,ymax_main,zero_band_radius,
                     length_of_zero_zone,bin_width,toString(merge_width),
                     toString(minimum_real_peak_factor),toString(peak_max_factor),
                     toString(real_peak_width),input_file_info$date)
    peak_calling_info[(i-1),] <- info_vector
  }
  #Populate combined dataframe if task contains 3
  if (length(which(task == 3)) != 0 && !is.null(deliverables$combined_col)) {
    TF_signal_raw_and_binary <- cbind(TF_signal_raw_and_binary,
                                      deliverables$combined_col[[1]])
    thresh_cutoff_txt <- cbind(thresh_cutoff_txt,
                               c(threshold_main,as.double(cutoff_factor)*as.double(threshold_main)))
  }
}
#Prepare .txt file to be exported (task 4)
if (length(which(task == 2)) != 0) {
  savename <- paste(save_dir,"/RiboPeak_PeakAlgorithm_",input_file_info$date,
                    ".txt",sep="")
  write.table(peak_calling_info,file=savename,row.names=FALSE,
              col.names=peak_calling_info_names,sep="\t")
}
#Prepare .txt file to be exported (task 3)
if (!is.null(TF_signal_raw_and_binary)) {
  #Convert to data frame
  TF_signal_raw_and_binary <- as.data.frame(TF_signal_raw_and_binary)
  thresh_cutoff_txt <- as.data.frame(thresh_cutoff_txt)
  headers <- sapply(colnums,toString)
  headers[1] <- "position"
  colnames(TF_signal_raw_and_binary) <- headers
  #Creation date of input file
  creation_date <- file.info(input_file_info$path)$mtime
  creation_date <- toString(creation_date)
  creation_date <- strsplit(creation_date," ")
  creation_date <- creation_date[[1]]
  creation_date <- paste(creation_date[1],"_",creation_date[2],sep="")
  creation_date <- strsplit(creation_date,":")
  creation_date <- creation_date[[1]]
  creation_date <- paste("(",creation_date[1],"h",creation_date[2],
                         "m",creation_date[3],"s",")",sep="")
  
  txt_save_name <- paste(input_file_info$species,"_Input_File_",creation_date,'_',
                         programName,"_withBinary_",input_file_info$date,".txt",sep="")
  #Create a save path for the file
  txt_save_path <- paste(save_dir,"/",txt_save_name,sep="")
  write.table(TF_signal_raw_and_binary[1:(length(TF_signal_raw_and_binary[,1])/2),],
              txt_save_path,sep="\t",row.names=FALSE)
  write.table(imported_data$other_info,txt_save_path,append=TRUE,sep="\t",row.names=FALSE,col.names=FALSE)
  write.table(thresh_cutoff_txt,txt_save_path,append=TRUE,sep="\t",row.names=FALSE,col.names=FALSE)
  write.table(TF_signal_raw_and_binary[(length(TF_signal_raw_and_binary[,1])/2 + 1):(length(TF_signal_raw_and_binary[,1])),],
              txt_save_path,append=TRUE,sep="\t",row.names=FALSE,col.names=FALSE)
}
cat(green$bold("\nAnalysis Complete!"))


