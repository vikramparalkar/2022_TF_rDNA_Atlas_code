library(ggplot2)
library(ggdendro)
library(dendextend)
library(cowplot)
library(gridExtra)
library(rstudioapi)
library(plyr)

####FUNCTIONS
#Function 1. (Finding the current date and species of file)
get.global.info <- function() {
  #Find date and time
  date_and_time <- Sys.time()
  date_and_time <- toString(date_and_time)
  date_and_time <- strsplit(date_and_time," ")
  date_and_time <- date_and_time[[1]]
  date_and_time <- paste(date_and_time[1],"_",date_and_time[2],sep="")
  date_and_time <- strsplit(date_and_time,":")
  date_and_time <- date_and_time[[1]]
  date_and_time <- paste("(",date_and_time[1],"h",date_and_time[2],
                         "m",date_and_time[3],"s",")",sep="")
  
  #Find path
  print('Please Select an Input File:')
  Sys.sleep(0.5);
  flush.console();
  input_filepath <- file.choose()
  #Find species through file name and assign parameters based on species
  input_filepath_split <- strsplit(input_filepath,"/")[[1]]
  input_filename <- input_filepath_split[length(input_filepath_split)]
  name <- strsplit(input_filename[[1]],'.',fixed = TRUE)[[1]][1]
  input_filename_split <- strsplit(input_filename,"_")[[1]]
  species <- NULL
  #Important global info
  species <- NULL
  min_peak_ratio_to_max <- NULL
  sim_w <-NULL
  cutoff_factor_base <- NULL
  cutoff_factor_coefficient <- NULL
  cut_height <- NULL
  min_height <- NULL
  min_members <- NULL
  #Get values for global info
  loop.input_filename_split <- 1:length(input_filename_split)
  for (i in loop.input_filename_split) {
    if (input_filename_split[i] == "Human") {
      species <- "Human"
      min_peak_ratio_to_max <- 0.1 #0.1
      sim_w <- 2.5
      cutoff_factor_base <- 1.3 #1.3
      cutoff_factor_coefficient <- 6
      cut_height <- 8.25
      min_height <- 12
      min_members <- 9
    }
    if (input_filename_split[i] == "Mouse") {
      species <- "Mouse"
      min_peak_ratio_to_max <- 0.3 #0.3
      sim_w <- 2.5
      cutoff_factor_base <- 1 #1
      cutoff_factor_coefficient <- 8.5
      cut_height <- 11.75
      min_height <- 15
      min_members <- 9
    }
  }
  
  #Assemble return value
  global_info <- list("date" = date_and_time, "filepath" = input_filepath,
                                "name" = name,"species" = species,
                                "min_peak_ratio_to_max" = min_peak_ratio_to_max,
                                "sim_weight" = sim_w, 
                                "cutoff_factor_base" = cutoff_factor_base,
                                "cutoff_factor_coefficient" = cutoff_factor_coefficient,
                                "cut_height"=cut_height,"min_height"=min_height,
                                "min_members"=min_members)
  return(global_info)
}

#Function 2. (Prompt user to select a save directory)
select.save.directory <- function() {
  print('Please Select a Save Directory:')
  Sys.sleep(0.5);
  flush.console();
  save_dir <- selectDirectory()
  return(save_dir)
}

#Function 3. (Convert file data to double)
convert.to.double <- function(col) {
  return(as.double(paste(col)))
}

#Function 4. (Import file and convert to numeric)
import.data <- function(global_info) {
  #Import whole file
  whole_file <- read.table(global_info$filepath,sep="\t",header=T)
  #Store Data
  raw_data <- NULL
  binary_data <- NULL
  unique_IDs <- NULL
  other_info <- NULL
  num_cols <- NULL
  #Format file to include all data and save unique IDs
  if (global_info$species == "Human") {
    raw_data <- whole_file[1:43000,]
    binary_data <- whole_file[43016:86015,]
    other_info <- whole_file[43001:43015,]
    unique_IDs <- whole_file[43005,]
    unique_IDs[1,1] <- 'Position'
    raw_data <- as.data.frame(raw_data)
    binary_data <- as.data.frame(binary_data)
    other_info <- as.data.frame(other_info)
    colnames(raw_data) <- unique_IDs
    colnames(binary_data) <- unique_IDs
    colnames(other_info) <- unique_IDs
    num_cols <- length(binary_data[1,])
  } else if (global_info$species == "Mouse") {
    raw_data <- whole_file[1:45306,]
    binary_data <- whole_file[45320:90625,]
    other_info <- whole_file[45307:45321,]
    unique_IDs <- whole_file[45311,]
    unique_IDs[1,1] <- 'Position'
    raw_data <- as.data.frame(raw_data)
    binary_data <- as.data.frame(binary_data)
    other_info <- as.data.frame(other_info)
    colnames(raw_data) <- unique_IDs
    colnames(binary_data) <- unique_IDs
    colnames(other_info) <- unique_IDs
    num_cols <- length(binary_data[1,])
  }
  #Convert raw_data to correct types
  raw_data <- sapply(raw_data,convert.to.double)
  binary_data <- sapply(binary_data,convert.to.double)
  #Assemble return data
  data.and.unique.IDs <- list("num_cols" = num_cols, "raw_data" = raw_data,
                              "binary_data" = binary_data, "unique_IDs" = unique_IDs,
                              "other_info" = other_info)
  return(data.and.unique.IDs)
}

#Function 5. (Exclude peak regions based on cutoff)
apply.cutoff <- function(other_info_col,binary_col,cfc,cfb) {
  raw_thresh <- as.double(paste(other_info_col[14]))
  if (raw_thresh == 0) {
    return(binary_col)
  } else {
    cutoff_factor <- NULL
    if (raw_thresh < cfc) {
      cutoff_factor <- (cfc/raw_thresh) + cfb
    } else {
      cutoff_factor <- 1 + cfb
    }
    below_cf <- which(binary_col < raw_thresh*cutoff_factor)
    binary_col[below_cf] <- 0
    return(binary_col)
  }
}

#Function 6. (Exclude peak regions based on minimum peak ratio to max of column)
apply.min.peak.ratio.to.max <- function(other_info_col,binary_col,mpr) {
  colMax <- as.double(paste(other_info_col[13]))
  below_mpr <- which(binary_col < (mpr*colMax))
  binary_col[below_mpr] <- 0
  return(binary_col)
}

#Function 7. (Convert maxes to 1s)
convert.to.ones <- function(binary_processed_data_col) {
  binary_ones_data_col <- binary_processed_data_col
  binary_ones_data_col[which(binary_processed_data_col > 0)] <- 1
  return(binary_ones_data_col)
}

#Function 8. (Apply correction algorithms)
correction.algorithms <- function(file_data,global_info) {
  #Exctract relevant quantities from global info regarding corrections
  cfb <- as.double(paste(global_info[['cutoff_factor_base']]))
  cfc <- as.double(paste(global_info[['cutoff_factor_coefficient']]))
  mpr <- global_info[['min_peak_ratio_to_max']]
  #Get binary data
  binary_data <- file_data[['binary_data']][,2:num_cols]
  #Create data frames to store the new data
  binary_cutoff_data <- binary_data
  binary_mpr_data <- binary_data
  binary_processed_data <- binary_data
  binary_ones_data <- binary_data
  file_data[['other_info']] <- file_data[['other_info']][,2:num_cols]
  #Create a loop for columns
  loop.col <- 1:length(binary_data[1,])
  #Loop through columns
  for (i in loop.col) {
    #Extract relevant current columns
    binary_col <- binary_data[,i]
    other_info_col <- file_data[['other_info']][,i]
    #Assign new data
    binary_cutoff_data[,i] <- apply.cutoff(other_info_col,binary_col,cfc,cfb)
    binary_mpr_data[,i] <- apply.min.peak.ratio.to.max(other_info_col,
                                                       binary_col,mpr)
    zero_indices_cutoff <- which(binary_cutoff_data[,i] == 0)
    zero_indices_mpr <- which(binary_mpr_data[,i] == 0)
    binary_processed_data[zero_indices_cutoff,i] <- 0
    binary_processed_data[zero_indices_mpr,i] <- 0
    binary_ones_data[,i] <- convert.to.ones(binary_processed_data[,i])
  }
  #Assemble return data
  corrected_data <- list('binary_cutoff_data' = binary_cutoff_data,
                         'binary_mpr_data' = binary_mpr_data,
                         'binary_processed_data' = binary_processed_data, 
                         'binary_ones_data' = binary_ones_data)
  return(corrected_data)
}

#Function 9. (Remove blank tracks)
remove.blank.tracks <- function(binary_ones_data,file_data) {
  binary_blanks_removed_data <- binary_ones_data[,colSums(binary_ones_data != 0) > 1]
  return(binary_blanks_removed_data)
}

#Function 10. (Calculate similarity scores)
calculate.sim.data <- function(global_info,binary_blanks_removed_data) {
  #Extract similarity weight
  sim_weight <- global_info[['sim_weight']]
  #Create a data frame to store results
  sim_data <- data.frame(rep(0,length(binary_blanks_removed_data[1,])))
  #Calculate sim scores
  loop.col <- 1:length(binary_blanks_removed_data[1,])
  for (i in loop.col) {
    print(i)
    col1 <- binary_blanks_removed_data[,i]
    scores <- rep(0,length(binary_blanks_removed_data[1,]))
    for (j in loop.col) {
      sim_score <- 0
      col2 <- binary_blanks_removed_data[,j]
      ones1 <- which(col1 == 1)
      ones2 <- which(col2 == 1)
      and <- length(intersect(ones1,ones2))
      or1 <- length(ones1) - and
      or2 <- length(ones2) - and
      if ((or1 == 0 && or2 == 0 && and == 0)) {
        
      } else {
        sim_score <- (sim_weight*and)/((or1 + or2) + sim_weight*and)
      }
      scores[j] <- sim_score
    }
    if (i == 1) {
      sim_data[,1] <- rev(scores)
    } else {
      sim_data <- cbind(sim_data,rev(scores))
    }
  }
  return(sim_data)
}

#Function 11. (Cluster similarity matrix)
cluster.sim.data <- function(sim_data,global_info) {
  #Cluster rows
  d1 <- dist(sim_data, method="euclidean")
  hc1 <- hclust(d1, method = "ward.D2")
  clust_order1 <- hc1$order
  sim_data <- as.data.frame(sim_data[clust_order1,])
  # Get groups from cutree
  groups <- cutree(hc1,h=global_info[['cut_height']]);
  groups <- groups[order(groups)]
  # Get labels from sim data and groups to ensure they have the same order
  sim_rnames <- rownames(sim_data)
  group_names <- names(groups)
  ordered_group_idx <- match(sim_rnames,group_names)
  # Reorder groups according to sim_data labels
  groups <- groups[ordered_group_idx]
  unordered_nums <- unique(groups)
  ordered_nums <- 1:max(unordered_nums)
  # Renumber groups via mapvalues
  groups <- mapvalues(groups,unordered_nums,ordered_nums)
  #Cluster columns
  sim_data <- t(sim_data)
  d2 <- dist(sim_data, method="euclidean")
  hc2 <- hclust(d2, method = "ward.D2")
  clust_order2 <- hc2$order
  sim_data <- sim_data[clust_order2,]
  sim_data <- t(sim_data)
  # Create dendrogram data
  dhc <- as.dendrogram(hc1)
  #Return results
  results <- list('clustered_sim_data'=sim_data,'dhc'=dhc,'groups'=groups)
  return(results)
}

#Function 12. (Find bad groups)
remove.bad.groups <- function(clustered_sim_data,raw_data,groups,global_info) {
  # Get parameters for removal
  min_height <- global_info[['min_height']]
  min_members <- global_info[["min_members"]]
  # Create variables to store bad groups
  bad_groups <- NULL
  # Create loop to go through groups
  loop.group <- 1:max(groups)
  # Loop through groups
  for (i in loop.group) {
    # Get row and col names
    clustered_col_names <- colnames(clustered_sim_data)
    clustered_row_names <- rownames(clustered_sim_data)
    # Find the members in group
    members_group <- which(groups == i)
    member_names <- names(members_group)
    # Locate corresponding rows and cols
    clustered_row_idx <- match(member_names,clustered_row_names)
    clustered_col_idx <- match(member_names,clustered_col_names)
    raw_col_idx <- match(member_names,colnames(raw_data))
    #### REMOVE BOOLEAN ####
    remove <- F
    #### CONDITION 1 ####
    # Extract clustered data
    curr_group_clustered_data <- clustered_sim_data[clustered_row_idx,clustered_col_idx]
    # Find number of members for condition 1
    num_members <- length(curr_group_clustered_data[,1])
    # First condition: less than nine members
    if (num_members < min_members) {
      remove <- T
      if (length(bad_groups) == 0) {
        bad_groups <- c(i)
      } else {
        bad_groups <- c(bad_groups,i)
      }
    }
    #### CONDITION 2 ####
    # Extract raw data
    curr_group_raw_data <- raw_data[,raw_col_idx]
    # Find the group mean
    group_mean <- rowMeans(curr_group_raw_data)
    # Find the max of the group mean
    max_group_mean <- max(group_mean)
    # Second condition: Max of average is at least 12
    if (max_group_mean < min_height) {
      remove <- T
      if (length(bad_groups) == 0) {
        bad_groups <- c(i)
      } else {
        bad_groups <- c(bad_groups,i)
      }
    }
    #### REMOVE GROUP IF NECESSARY ####
    if (isTRUE(remove)) {
      clustered_sim_data <- clustered_sim_data[-clustered_row_idx,]
      clustered_sim_data <- clustered_sim_data[,-clustered_col_idx]
      groups <- groups[-members_group]
    }
  }
  # Remove duplicates
  bad_groups <- unique(bad_groups)
  # Assemble return data
  return_data <- list('bad_groups'=bad_groups,
                      'clustered_data_bad_removed'=clustered_sim_data,
                      'groups_bad_removed'=groups)
  # Return results
  return(return_data)
}

#Function 13. (Update Dendrogram info)
recluster.data <- function(clustered_data_bad_removed) {
  #Cluster rows
  d1 <- dist(clustered_data_bad_removed, method="euclidean")
  hc1 <- hclust(d1, method = "ward.D2")
  clust_order1 <- hc1$order
  clustered_data_bad_removed <- as.data.frame(clustered_data_bad_removed[clust_order1,])
  # Get groups from cutree
  groups <- cutree(hc1,h=global_info[['cut_height']]);
  # Get labels from clust data and groups to ensure they have the same order
  clust_rnames <- rownames(clustered_data_bad_removed)
  group_names <- names(groups)
  ordered_group_idx <- match(clust_rnames,group_names)
  # Reorder groups according to sim_data labels
  groups <- groups[ordered_group_idx]
  unordered_nums <- unique(groups)
  ordered_nums <- 1:max(unordered_nums)
  # Renumber groups via mapvalues
  groups <- mapvalues(groups,unordered_nums,ordered_nums)
  groups <- as.data.frame(groups)
  View(groups)
  #Cluster columns
  clustered_data_bad_removed <- t(clustered_data_bad_removed)
  d2 <- dist(clustered_data_bad_removed, method="euclidean")
  hc2 <- hclust(d2, method = "ward.D2")
  clust_order2 <- hc2$order
  clustered_data_bad_removed <- clustered_data_bad_removed[clust_order2,]
  clustered_data_bad_removed <- t(clustered_data_bad_removed)
  # Export new groupings as a txt file
  groups_save_path <- paste(save_dir,'/',global_info[['name']],'_SIMILARITYMATRIX_Groups_h8.25_',
                            global_info[['date']],'.txt',sep='')
  write.table(groups,groups_save_path,sep="\t",col.names=NA)
  # Extract new dendrogram
  dhc <- as.dendrogram(hc1)
  # Troubleshooting
  #View(groups)
  #View(clustered_data_bad_removed)
  # Assemble return data
  return_data <- list('final_clust_data'=clustered_data_bad_removed,
                      'groups'=groups,'dhc'=dhc,'max_height'=max(hc1$height))
  # Return results
  return(return_data)
}

#Function 14. (Create rectangle data)
create.group.rects <- function(max_dend_height,groups) {
  # Preallocate memory for data frame
  y_min <- rep(0,max(groups))
  y_max <- rep(1.05*max_dend_height,max(groups))
  x_min <- rep(0,max(groups))
  x_max <- rep(0,max(groups))
  color <- rep('',max(groups))
  rect_data <- as.data.frame(cbind(x_min,x_max,y_min,y_max,color))
  # Create color palette
  colors <- c('gold','deepskyblue','firebrick1','chartreuse4')
  # Assign yvalues and colors to dataframe
  loop.group <- 1:max(groups)
  curr_ymin <- 0.5
  for (i in loop.group) {
    members <- which(groups == i)
    rect_height <- length(members)
    rect_data[['x_min']][i] <- curr_ymin
    rect_data[['x_max']][i] <- curr_ymin+rect_height 
    rect_data[['color']][i] <- colors[i%%4 + 1]
    curr_ymin <- curr_ymin + rect_height
  }
  # Convert to double
  rect_data[['x_min']] <- convert.to.double(rect_data[['x_min']])
  rect_data[['x_max']] <- convert.to.double(rect_data[['x_max']])
  rect_data[['y_min']] <- convert.to.double(rect_data[['y_min']])
  rect_data[['y_max']] <- convert.to.double(rect_data[['y_max']])
  return(rect_data)
}

#Function 15. (Arrange sim data for plotting)
arrange.sim.data <- function(final_clust_data) {
  sim_scores <- rep(0,(length(final_clust_data[,1])*
                         length(final_clust_data[,1])))
  x <- rep(0,(length(final_clust_data[,1])*
                length(final_clust_data[,1])))
  y <- rep(0,(length(final_clust_data[,1])*
                length(final_clust_data[,1])))
  index <- 1
  loop.col <- 1:length(final_clust_data[,1])
  for (i in loop.col) {
    for (j in loop.col) {
      sim_scores[index] <- final_clust_data[i,j]
      x[index] <- j
      y[index] <- i
      index <- index + 1
    }
  }
  #Arrange Return Data
  return_data <- list('sim_scores' = sim_scores, 'x' = x, 'y' = y)
  return(return_data)
}

#Function 16. (Plot and save)
plot.and.save.sim.matrix <- function(clustered_sim_data,sim_scores,x,y,
                                     dhc,rect_data,global_info,save_dir) {
  name <- global_info[['name']]
  cfb <- global_info[['cutoff_factor_base']]
  cfc <- global_info[['cutoff_factor_coefficient']]
  mpr <- global_info[['min_peak_ratio_to_max']]
  sw <- global_info[['sim_weight']]
  date <- global_info[['date']]
  
  xticks <- colnames(clustered_sim_data)
  yticks <- rownames(clustered_sim_data)
  b <- 1:length(xticks)
  
  sim_data <- data.frame(x=x,y=y,score=sim_scores)
  
  save_path <- paste(save_dir,'/',name,'_SIMILARITYMATRIX_cfb_',cfb,'_cfc_',cfc,
                     '_mpr_',mpr,'_sw_',sw,'_',date,'.png',sep='')

  #Create variable for automatic font size scaling
  tick_label_size = 1000/length(clustered_sim_data[,1])
  if (tick_label_size > 18) {
    tick_label_size <- 18
  }
  
  # Create dendrogram data for plotting
  ddata <- dendro_data(dhc,type='rectangle')
  ddata <- segment(ddata)
  # xzoom and yzoom for dendrogram
  xzoom <- c(0.5,length(xticks)+0.5)
  maxy <- max(max(ddata[['y']]),max(ddata[['yend']]))
  yzoom <- c(1.05*maxy,0)
  
  # Create line data for dendrogram
  line_df <- data.frame('x'=c(0.5,length(xticks)+0.5),
                        'y'=c(global_info[['cut_height']],global_info[['cut_height']]))
  
  p1 <- ggplot() + geom_tile(data=sim_data, aes(x=x,y=y,fill=score)) + 
    theme_bw() + theme(plot.background=element_rect(fill="white")) +
    scale_y_continuous(name="",breaks=b,labels=yticks) +
    scale_x_continuous(name="",breaks=b,labels=xticks) +
    scale_fill_viridis_c(option = "magma") +
    theme(legend.position = 'none') +
    theme(axis.text.y = element_text(size=tick_label_size)) +
    theme(axis.text.x = element_text(angle = 90,hjust=0.95,vjust=0.2,size=tick_label_size)) +
    theme(axis.ticks = element_blank()) +
    theme(panel.grid.major=element_blank(),panel.grid.minor=element_blank()) +
    theme(plot.margin = unit(c(2, 2, 0, 0), "cm")) +
    coord_equal(expand=F)
  
  p2 <- ggplot() + 
    geom_segment(data=ddata, aes(x=x,y=y,xend=xend,yend=yend)) +
    geom_rect(data=rect_data, aes(xmin=x_min,xmax=x_max,ymin=y_min,ymax=y_max,fill=color),
              alpha=0.2,show.legend = FALSE) +
    geom_line(data=line_df, aes(x=x,y=y), color='red') +
    scale_fill_manual(values=c('gold'='gold','deepskyblue'='deepskyblue',
                               'firebrick1'='firebrick1','chartreuse4'='chartreuse4')) +
    theme_bw() + theme(plot.background=element_rect(fill="white")) +
    theme(axis.text.y = element_text(size=tick_label_size)) +
    theme(panel.grid.major=element_blank(),panel.grid.minor=element_blank()) +
    theme(plot.margin = unit(c(2, 0.5, 0, 0), "cm")) +
    scale_x_continuous(name="",breaks=b,labels=yticks) +
    coord_flip(xlim=xzoom,ylim=yzoom,expand=F) + scale_y_reverse()
    
  p <- plot_grid(p2,p1,nrow=1,align='h',axis='tblr')
  
  save_plot(save_path,p,ncol=1,nrow=1,base_height = 15,base_asp=2) #base_asp=1.618
  
  return(p)
}

#Function 17. (Save as txt file)
save.as.txt <- function(clustered_sim_data,global_info,save_dir) {
  name <- global_info[['name']]
  cfb <- global_info[['cutoff_factor_base']]
  cfc <- global_info[['cutoff_factor_coefficient']]
  mpr <- global_info[['min_peak_ratio_to_max']]
  sw <- global_info[['sim_weight']]
  date <- global_info[['date']]
  txt_save_path <- paste(save_dir,'/',name,'_SIMILARITYMATRIX_cfb_',cfb,'_cfc_',cfc,
                         '_mpr_',mpr,'_sw_',sw,'_',date,'.txt',sep='')
  clustered_sim_data <- clustered_sim_data[length(clustered_sim_data[1,]):1,]
  write.table(clustered_sim_data,txt_save_path,sep="\t",col.names=NA)
}

####Main Body
#Find global variables
global_info <- get.global.info()
#Set up a save directory
save_dir <- select.save.directory()
#Import and process all data
file_data <- import.data(global_info)
num_cols <- file_data[['num_cols']]
raw_data <- file_data[['raw_data']]
print('File Imported!')
#Apply correction algorithms
corrected_data <- correction.algorithms(file_data,global_info)
binary_cutoff_data <- corrected_data[['binary_cutoff_data']]
binary_mpr_data <- corrected_data[['binary_mpr_data']]
binary_processed_data <- corrected_data[['binary_processed_data']]
binary_ones_data <- corrected_data[['binary_ones_data']]
print("Corrections Done!")
#Remove empty tracks
binary_blanks_removed_data <- remove.blank.tracks(binary_ones_data,file_data)
binary_blanks_removed_data <- binary_blanks_removed_data[,
                              -match(c("POLR1A_SRX7707600_r_mm9_rDNA_GEO_PreBcell",
                                       "SP110_SRX4909437_r_mm9_rDNA_GEO_RAW2647",
                                      "NR3C1_SRX745824_r_mm9_rDNA_GEO_BFUE",
                                      "CEBPE_SRX1318197_r_mm9_rDNA_GEO_BoneMarrow"),
                                     colnames(binary_blanks_removed_data))]
print('Blanks Removed!')
print('Num of Cols:')
print(length(binary_blanks_removed_data[1,]))
#Calculate similarity scores and return as a new data frame
sim_data <- calculate.sim.data(global_info,binary_blanks_removed_data)
#Set rownames and colnames for easy identification
sim_unique_IDs <- colnames(binary_blanks_removed_data)
colnames(sim_data) <- sim_unique_IDs
rownames(sim_data) <- rev(sim_unique_IDs)
print('Similarity Data Created!')
#Cluster the similarity data
cluster_data <- cluster.sim.data(sim_data,global_info)
clustered_sim_data <- cluster_data[["clustered_sim_data"]]
groups <- cluster_data[['groups']]
dhc <- cluster_data[['dhc']]
print('Similarity Data Clustered!')
# Remove bad groups
bad_groups_data <- remove.bad.groups(clustered_sim_data,raw_data,groups,global_info)
bad_groups <- bad_groups_data[['bad_groups']]
clustered_sim_data_bad_removed <- bad_groups_data[['clustered_data_bad_removed']]
groups_bad_removed <- bad_groups_data[['groups_bad_removed']]
# Recluster and regroup data
reclustered_data <- recluster.data(clustered_sim_data_bad_removed)
final_clust_data <- reclustered_data[['final_clust_data']]
groups <- reclustered_data[['groups']]
dhc <- reclustered_data[['dhc']]
max_dend_height <- reclustered_data[['max_height']]
print('Data Reclustered!')
# Create rectangles to show groups
rect_data <- create.group.rects(max_dend_height,groups)
#Arrange similarity scores for plotting
arranged_sim_score_data <- arrange.sim.data(final_clust_data)
sim_scores <- arranged_sim_score_data$sim_scores
x_positions <- arranged_sim_score_data$x
y_positions <- arranged_sim_score_data$y
#Plot and save similarity matrix
plot.and.save.sim.matrix(final_clust_data,sim_scores,x_positions,y_positions,
                         dhc,rect_data,global_info,save_dir)
#Export similarity matrix as a txt file
save.as.txt(clustered_sim_data_bad_removed,global_info,save_dir)
print('Analysis Complete!')