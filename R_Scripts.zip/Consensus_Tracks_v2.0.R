library(ggplot2)
library(ggdendro)
library(cowplot)
library(gridExtra)
library(rstudioapi)
library(matrixStats)

signal_data <- NULL
processed_signal_data <- NULL
grouping_data <- NULL
unique_IDs <- NULL
other_info <- NULL
num_cols <- NULL
cutpos <- NULL

####FUNCTIONS
#Function 1. (Finding the current date and species of file)
get.global.info <- function() {
  #Find date and time
  date_and_time <- Sys.time()
  date_and_time <- toString(date_and_time)
  date_and_time <- strsplit(date_and_time," ")
  date_and_time <- date_and_time[[1]]
  date_and_time <- paste(date_and_time[1],"_",date_and_time[2],sep="")
  date_and_time <- strsplit(date_and_time,":")
  date_and_time <- date_and_time[[1]]
  date_and_time <- paste("(",date_and_time[1],"h",date_and_time[2],
                         "m",date_and_time[3],"s",")",sep="")
  
  #Find path
  print('Please Select a R1B0ZONE Output File as an Input:')
  Sys.sleep(0.5);
  flush.console();
  input_filepath <- file.choose()
  print('Please Select a Grouping File:')
  Sys.sleep(0.5);
  flush.console();
  grouping_filepath <- file.choose()
  #Find species through file name and assign parameters based on species
  input_filepath_split <- strsplit(input_filepath,"/")[[1]]
  input_filename <- input_filepath_split[length(input_filepath_split)]
  name <- strsplit(input_filename[[1]],'.',fixed = TRUE)[[1]][1]
  input_filename_split <- strsplit(input_filename,"_")[[1]]
  species <- NULL
  #Important global info
  species <- NULL
  #Get values for global info
  loop.input_filename_split <- 1:length(input_filename_split)
  for (i in loop.input_filename_split) {
    if (input_filename_split[i] == "Human") {
      species <- "Human"
    }
    if (input_filename_split[i] == "Mouse") {
      species <- "Mouse"
    }
  }
  
  #Assemble return value
  global_info <- list("date" = date_and_time, "filepath" = input_filepath,
                      'grouping_filepath'=grouping_filepath,
                      "name" = name,"species" = species)
  return(global_info)
}

#Function 2. (Prompt user to select a save directory)
select.save.directory <- function() {
  print('Please Select a Save Directory:')
  Sys.sleep(0.5);
  flush.console();
  save_dir <- selectDirectory()
  return(save_dir)
}

#Function 3. (Convert file data to double)
convert.to.double <- function(col) {
  return(as.double(paste(col)))
}

#Function 4. (Import file and convert to numeric)
import.data <- function(global_info) {
  #Import whole file
  data_file <- read.table(global_info$filepath,sep="\t",header=T)
  group_file <- read.table(global_info$grouping_filepath,sep="\t",header=T)
  
  #Format file to include all data and save unique IDs
  if (global_info$species == "Human") {
    signal_data <<- as.data.frame(data_file[1:43000,])
    grouping_data <<- as.data.frame(group_file[1:length(group_file[,1]),])
    other_info <<- as.data.frame(data_file[43001:43015,])
    unique_IDs <<- data_file[43005,]
    unique_IDs[1,1] <<- 'Position'
    colnames(signal_data) <<- unique_IDs
    colnames(other_info) <<- unique_IDs
    num_cols <<- length(grouping_data[,1])
    cutpos <<- 40000
  } else if (global_info$species == "Mouse") {
    signal_data <<- as.data.frame(data_file[1:45306,])
    grouping_data <<- as.data.frame(group_file[1:length(group_file[,1]),])
    other_info <<- as.data.frame(data_file[45307:45321,])
    unique_IDs <<- data_file[45311,]
    unique_IDs[1,1] <<- 'Position'
    colnames(signal_data) <<- unique_IDs
    colnames(other_info) <<- unique_IDs
    num_cols <<- length(grouping_data[,1])
    cutpos <<- 42000
  }
  #Convert raw_data to correct types
  signal_data <<- sapply(signal_data,convert.to.double)
}

# Function 5. (Get rid of unnecessary columns)
remove.cols <- function() {
  signal_indices <- match(grouping_data[,1],unique_IDs[1,])
  processed_signal_data <<- signal_data[,signal_indices]
  unique_IDs <<- unique_IDs[1,signal_indices]
}

# Function 6.
create.consensus <- function(group_data) {
  ymean <- rep(0,length(group_data[,1]))    # Means
  ymax <- rep(0,length(group_data[,1])) # Upper bound of SEM
  ymin <- rep(0,length(group_data[,1])) # Lower bound of SEM
  ymean <- rowMeans(group_data)
  # Calculate stds
  stds <- rowSds(group_data)
  ymax <- ymean + stds/sqrt(length(group_data[1,]))
  ymin <- ymean - stds/sqrt(length(group_data[1,]))
  consensus_data <- data.frame('position'=(signal_data[,1]-rep(1,length(signal_data[,1]))),
                               'ymean'=ymean,'ymax'=ymax,'ymin'=ymin)
  # Return Results
  return(consensus_data)
}

#Function 7.
create.box.data <- function(global_info) {
  ####Set up relevant vectors for box schematic dataframe
  position <- c(0:(length(signal_data[,1])-1))
  feature <- rep(NULL,length(signal_data[,1]))
  value <- rep(5,length(signal_data[,1]))
  species <- global_info[['species']]
  ####Populate vectors for dataframe
  if (species == "Human") {
    feature[1:3656] <- "5' ETS"
    feature[3657:5527] <- "18S"
    feature[5528:6622] <- "ITS1"
    feature[6623:6779] <- "5.8S"
    feature[6780:7934] <- "ITS2"
    feature[7935:12969] <- "28S"
    feature[12970:13314] <- "3' ETS"
    feature[13315:42127] <- "IGS"
    feature[42128:42307] <- "SpPr"
    feature[42353:42370] <- "Tsp"
    feature[42372:42814] <- "Enhancer"
    feature[42815:42832] <- "T0"
    feature[42834:43000] <- "47sPr"
  } else if (species == "Mouse") {
    feature[1:4007] <- "5' ETS"
    feature[4008:5877] <- "18S"
    feature[5878:6877] <- "ITS1"
    feature[6878:7034] <- "5.8S"
    feature[7035:8122] <- "ITS2"
    feature[8123:12852] <- "28S"
    feature[12853:13403] <- "3' ETS"
    feature[13404:43168] <- "IGS"
    feature[43169:43312] <- "SpPr"
    feature[43371:43388] <- "Tsp"
    feature[43389:45134] <- "Enhancer"
    feature[45135:45154] <- "T0"
    feature[45165:45306] <- "47sPr"
  }
  #Create data frame
  box_data <- data.frame(position,feature,value)
  #Return statement
  return(box_data)
}

# Function 8.
cut.track <- function(consensus_data,box_data) {
  #Renumber positions according to cut location and save as a new data frame
  start_index <- cutpos - (length(consensus_data[["position"]]))
  subtract_index <- consensus_data[["position"]][1] - start_index
  new_pos <- consensus_data[["position"]] - subtract_index
  new_pos <- as.data.frame(new_pos)
  #Rearrange consensus_data according to cut location
  consensus_pre <- consensus_data[cutpos:(length(consensus_data[["position"]])),]
  consensus_post <- consensus_data[1:cutpos-1,]
  box_pre <- box_data[cutpos:(length(consensus_data[["position"]])),]
  box_post <- box_data[1:cutpos-1,]
  consensus_data <- rbind(consensus_pre,consensus_post)
  box_data <- rbind(box_pre,box_post)
  consensus_data[["position"]] <- new_pos[["new_pos"]]
  box_data[["position"]] <- new_pos[["new_pos"]]
  #Refactor features for schematic legend
  box_data$feature <- factor(box_data$feature, 
                             levels=c("5' ETS","18S","ITS1","5.8S","ITS2","28S", 
                                      "3' ETS","IGS","SpPr","Tsp","Enhancer", 
                                      "T0","47sPr"),
                             labels=c("5' ETS","18S","ITS1","5.8S","ITS2","28S", 
                                      "3' ETS","IGS","SpPr","Tsp","Enhancer", 
                                      "T0","47sPr"))
  # Renumber rows
  row.names(consensus_data) <- NULL
  row.names(box_data) <- NULL
  #Assemble Return Data
  return_data <- list('cut_consensus_data'=consensus_data,'cut_box_data'=box_data)
  # Return results
  return(return_data)
}

# Function 9.
plot.and.save <- function(cut_consensus_data,cut_box_data,i,global_info,save_dir) {
  # Set zoom for plot
  xzoom <- c(min(cut_consensus_data[['position']]),max(cut_consensus_data[['position']]))
  yzoom <- c(0,1.02*max(cut_consensus_data[['ymean']]))
  # 30 is minimum ymax
  if (yzoom[2] < 30) {
    yzoom[2] <- 30
  }
  # Construct consensus plot
  p1 <- ggplot() + 
    geom_bar(data=cut_consensus_data,stat='identity',width=1.0,aes(x=position,y=ymean),fill="firebrick1") +
    coord_cartesian(xlim=c(xzoom[1],xzoom[2]),ylim=c(yzoom[1],yzoom[2]),expand=F) +
    xlab('Position') + ylab('Consensus Signal') + ggtitle(unique_groups[i]) +
    theme_bw() +
    theme(axis.title.y=element_text(size=20),
          axis.title.x=element_text(size=20),
          axis.text.y=element_text(size=20),
          axis.text.x=element_text(size=20),
          axis.ticks = element_blank(),
          plot.title=element_text(size=24,face="bold"),
          panel.grid.major = element_blank(),
          panel.grid.minor = element_blank(),
          panel.border=element_rect(fill=NA,colour="black",size=2))
  #Construct schematic plot
  p2 <- ggplot(cut_box_data) + 
    geom_bar(stat="identity",width=1.0,aes(x=position, y=value, fill=feature)) + 
    scale_fill_manual(values=c("steelblue","yellow3","steelblue","yellow3", 
                               "steelblue","yellow3","steelblue","grey46",
                               "darkorange3","pink","green4",
                               "pink", "darkorange3", "black")) + 
    coord_cartesian(xlim=c(xzoom[1],xzoom[2]),ylim=c(-2.5,7.5),expand=F) + 
    theme_bw() + 
    theme(panel.grid.major=element_blank(),panel.grid.minor=element_blank()) +
    theme(axis.title.y=element_blank()) +
    theme(axis.text.y=element_text(size=20)) +
    theme(axis.text.y=element_text(color='#ffffff')) +
    theme(axis.title.x=element_text(size=20)) +
    theme(axis.text.x=element_text(size=20)) +
    theme(legend.position="none") +
    theme(panel.border=element_rect(fill=NA,colour="black",size=2)) +
    theme(axis.ticks.length=unit(0.25,"cm")) +
    theme(axis.ticks=element_line(colour="black",size=1)) +
    scale_y_continuous(breaks=c(-5,0,5),labels=c('9999','9999','9999'))
  # Grid plots together
  final_plot <- plot_grid(p1,p2,ncol=1,align="v",axis="b")
  # Prepare to save
  save_path <- paste(save_dir,'/',global_info[['species']],
                     '_ConsensusTrack_numgroups_',
                     toString(length(unique_groups)),'_Group_',i,
                     '_',global_info[['date']],'.png',sep='')
  save_plot(save_path,final_plot,ncol=1,nrow=2,base_height = 3.71,base_asp=6)
  # Return
  return(final_plot)
}

# Function 10.
export.as.txt <- function(consensus_data,i,global_info,save_dir) {
  # Create save path for the .txt file
  save_path <- paste(save_dir,'/',global_info[['species']],
                     '_ConsensusTrack_numgroups_',
                     toString(length(unique_groups)),'_Group_',i,
                     '_',global_info[['date']],'.txt',sep='')
  # Create the .txt file
  write.table(consensus_data[,1:2],save_path,sep="\t",row.names=FALSE)
}



####MAIN BODY
# Get global info
global_info <- get.global.info()
# Choose save directory
save_dir <- select.save.directory()
# Import data
import.data(global_info)
# Remove unnecessary columns
remove.cols()
# Get a list of unique group names
unique_groups <- unique(grouping_data[,2])
# Loop through group numbers and create consensus tracks
group.loop <- 1:length(unique_groups)
for (i in group.loop) {
  print(unique_groups[i])
  # Get unique IDs of group members
  group_members <- grouping_data[which(grouping_data[,2] == unique_groups[i]),1]
  # Get column numbers of group members in signal_data
  member_indices <- match(group_members,unique_IDs)
  # Get data corresponding to group
  group_data <- processed_signal_data[,member_indices]
  # Create consensus data
  consensus_data <- create.consensus(group_data)
  # Create box data
  box_data <- create.box.data(global_info)
  # Cut data
  cut_data <- cut.track(consensus_data,box_data)
  cut_consensus_data <- cut_data[['cut_consensus_data']]
  cut_box_data <- cut_data[['cut_box_data']]
  # Plot and save consensus data
  p <- plot.and.save(cut_consensus_data,cut_box_data,i,global_info,save_dir)
  # Export data as .txt file
  export.as.txt(consensus_data,i,global_info,save_dir)
}
